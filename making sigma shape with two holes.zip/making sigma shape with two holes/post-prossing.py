# frist run this code it solve the freezing
import numpy as np
import array
from abaqus import *
from abaqusConstants import *

def extract_nodal_data(model_name, node_set_name, step_name, variable_name, component):
    odb = session.openOdb(model_name + '.odb')
    step = odb.steps[step_name]
    node_set = odb.rootAssembly.nodeSets[node_set_name]
    nodal_data_all_increments = []
    for increment in step.frames:
        variable = increment.fieldOutputs[variable_name]
        variable_subset = variable.getSubset(region=node_set)
        nodal_data = []
        for value in variable_subset.values:
            nodal_data.append(value.data[component])
        nodal_data_all_increments.append(nodal_data)
    np.savetxt(str(variable_name) + '_' + str(model_name) + '.txt', nodal_data_all_increments)


import array
H = array.array('i', [200,250, 300, 350])
B = array.array('i', [50,70, 100, 120])
S = array.array('i', [20,25, 30, 35])
T = array.array('i', [2,3,4])
L = array.array('i', [50,75,100])

cc=0

for h in H:
    for b in B:
        for s in S:
            for t in T:
                for l in L:
                    R = array.array('f', [0.12*h, 0.16*h, 0.18*h])
                    for raduis in R:
                        cc=cc+1
                        L1 = b
                        L2 = 0.37 * b
                        h1 = s
                        h2 = 0.2 * h
                        h3 = (1 / 17) * h
                        h4 = 0.47 * h
                        thick = t
                        beam_depth = 400
                        bearing_lengnth = l
                        displacement = 40
                        mesh_size = 8
                        model_name = 'BeamModel-'+str(cc)+ "h="+ str(h) + '-' +"b="+ str(b) + '-' +"s="+ str(s) + '-' +"t="+ str(t) + '-' +"l="+ str(l)
                        extract_nodal_data(model_name, "REFERENCE_POINT_        2", "loading", "U", 1)
                        extract_nodal_data(model_name, "REFERENCE_POINT_        1", "loading", "RF", 1)

from abaqus import *
from abaqusConstants import *
import regionToolset
import __main__
import section
import regionToolset
import part
import material
import assembly
import step
import interaction
import load
import mesh
import job
import sketch
import visualization
import xyPlot
import connectorBehavior
import odbAccess
from operator import add
import os
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
from abaqus import *
from abaqusConstants import *
import matplotlib.pyplot as plt
import numpy as np
from abaqus import *
from abaqusConstants import *
import matplotlib.pyplot as plt

output_folder = 'output'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)


def extract_nodal_data(model_name, node_set_name, step_name, variable_name, component):
    odb = session.openOdb(model_name + '.odb')
    step = odb.steps[step_name]
    node_set = odb.rootAssembly.nodeSets[node_set_name]
    nodal_data_all_increments = []
    for increment in step.frames:
        variable = increment.fieldOutputs[variable_name]
        variable_subset = variable.getSubset(region=node_set)
        nodal_data = []
        for value in variable_subset.values:
            nodal_data.append(value.data[component])
        nodal_data_all_increments.append(nodal_data)
    np.savetxt(os.path.join(output_folder, "{}_{}.txt".format(variable_name, model_name)), nodal_data_all_increments)
    max_data = Create_Sum_ABS_List(nodal_data_all_increments)
    # Create_Plot(range(len(nodal_data_all_increments)), nodal_data_all_increments, len(nodal_data_all_increments), max_data, model_name)


def Create_Sum_ABS_List(data):
    max_data = max(data)
    return max_data


# def Create_Plot(data_1, data_2, max_data_1, max_data_2, model_name):
#     fig, ax = plt.subplots()
#     for i, d in enumerate(data_2):
#         ax.plot(data_1, data_2, '-o')
#     legend = ax.legend(loc='lower right', shadow=True)
#     plt.ylabel('Force [N]')
#     plt.xlabel('Displacement [mm]')
#     plt.grid(True)
#     plt.axis([0.0, max_data_1, 0.0, max(max_data_2)])
#     max_value = max(max_data_2)
#     plt.text(max_data_1*0.8, max_value*0.8, 'Max value: {:.2f} kN'.format(max_value/1000), bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=1'))
#     plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
#     plt.savefig(os.path.join(output_folder, "Load_Displacement_Curve_{}.png".format(model_name)))



def write_max_rf(model_name, output_file):
    data = np.loadtxt("RF_" + model_name + ".txt")
    max_rf = max(data)
    with open(output_file, "a") as file:
        file.write(model_name + "\t" + str(max_rf/1000) + "\n")
    with open(os.path.join(output_folder, output_file), "a") as file:
        file.write(model_name + "\t" + str(max_rf / 1000) + "\n")

output_file = "max_rf.txt"

import array
H = array.array('i', [200,250, 300, 350])
B = array.array('i', [50,70, 100, 120])
S = array.array('i', [20,25, 30, 35])
T = array.array('i', [2,3,4])
L = array.array('i', [50,75,100])

cc=0

for h in H:
    for b in B:
        for s in S:
            for t in T:
                for l in L:
                    R = array.array('f', [0.12*h, 0.16*h, 0.18*h])
                    for raduis in R:
                        cc=cc+1
                        L1 = b
                        L2 = 0.37 * b
                        h1 = s
                        h2 = 0.2 * h
                        h3 = (1 / 17) * h
                        h4 = 0.47 * h
                        thick = t
                        beam_depth = 400
                        bearing_lengnth = l
                        displacement = 40
                        mesh_size = 8
                        model_name = 'BeamModel-'+str(cc)+ "h="+ str(h) + '-' +"b="+ str(b) + '-' +"s="+ str(s) + '-' +"t="+ str(t) + '-' +"l="+ str(l)
                        extract_nodal_data(model_name, "REFERENCE_POINT_        2", "loading", "U", 1)
                        extract_nodal_data(model_name, "REFERENCE_POINT_        1", "loading", "RF", 1)
                        write_max_rf(model_name, output_file)

