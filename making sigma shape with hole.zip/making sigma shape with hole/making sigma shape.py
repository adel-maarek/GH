# creating parts
import array
from abaqus import mdb
from abaqusConstants import *
import regionToolset


def i3D_Beam(raduis,L1, L2, h1, h2, h3, h4, model_name, thick, beam_depth, bearing_lengnth, displacement, mesh_size):
    # making part
    mdb.Model(name=model_name, modelType=STANDARD_EXPLICIT)
    s = mdb.models[model_name].ConstrainedSketch(name='__profile__',
                                                 sheetSize=500.0)
    g, v, d, c = s.geometry, s.vertices, s.dimensions, s.constraints
    s.setPrimaryObject(option=STANDALONE)
    s.Line(point1=(L1, h1), point2=(L1, 0.0))
    s.Line(point1=(L1, 0.0), point2=(0.0, 0.0))
    s.Line(point1=(0.0, 0.0), point2=(0.0, h2))
    s.Line(point1=(0.0, h2), point2=(L2, h2 + h3))
    s.Line(point1=(L2, h2 + h3), point2=(L2, h2 + h3 + h4))
    s.Line(point1=(L2, h2 + h3 + h4), point2=(0.0, h2 + 2 * h3 + h4))
    s.Line(point1=(0.0, h2 + 2 * h3 + h4), point2=(0.0, 2 * h2 + 2 * h3 + h4))
    s.Line(point1=(0.0, 2 * h2 + 2 * h3 + h4), point2=(L1, 2 * h2 + 2 * h3 + h4))
    s.Line(point1=(L1, 2 * h2 + 2 * h3 + h4), point2=(L1, 2 * h2 + 2 * h3 + h4 - h1))
    p = mdb.models[model_name].Part(name='Beam', dimensionality=THREE_D,
                                    type=DEFORMABLE_BODY)
    p = mdb.models[model_name].parts['Beam']
    p.BaseShellExtrude(sketch=s, depth=beam_depth)
    s.unsetPrimaryObject()
    p = mdb.models[model_name].parts['Beam']
    del mdb.models[model_name].sketches['__profile__']
    # defining the matrial
    mdb.models[model_name].Material(name='Stanless Steel 37')
    mdb.models[model_name].materials['Stanless Steel 37'].Density(table=((
                                                                               7.85e-09,),))
    mdb.models[model_name].materials['Stanless Steel 37'].Elastic(table=((
                                                                               210000.0, 0.3),))
    mdb.models[model_name].materials['Stanless Steel 37'].Plastic(
        scaleStress=None, table=((240.0, 0.0), (360.0, 0.2)))
    # assining section
    mdb.models[model_name].HomogeneousShellSection(name='Section-beam',
                                                   preIntegrate=OFF, material='Stanless Steel 37',
                                                   thicknessType=UNIFORM,
                                                   thickness=thick, thicknessField='', nodalThicknessField='',
                                                   idealization=NO_IDEALIZATION, poissonDefinition=DEFAULT,
                                                   thicknessModulus=None, temperature=GRADIENT, useDensity=OFF,
                                                   integrationRule=SIMPSON, numIntPts=5)
    f = p.faces[:]
    region = p.Set(faces=f, name='the-whole-model')
    p.SectionAssignment(region=region, sectionName='Section-beam', offset=0.0,
                        offsetType=MIDDLE_SURFACE, offsetField='',
                        thicknessAssignment=FROM_SECTION)
    # creating a datum plane and partition
    p = mdb.models[model_name].parts['Beam']
    p.DatumPlaneByPrincipalPlane(principalPlane=XYPLANE, offset=beam_depth - bearing_lengnth)
    p = mdb.models[model_name].parts['Beam']
    f = p.faces[:]
    d1 = p.datums
    p.PartitionFaceByDatumPlane(datumPlane=d1[3], faces=f)
    # making assumbly
    a = mdb.models[model_name].rootAssembly
    a = mdb.models[model_name].rootAssembly
    a.DatumCsysByDefault(CARTESIAN)
    p = mdb.models[model_name].parts['Beam']
    a.Instance(name='Beam-1', part=p, dependent=ON)
    # creating step
    mdb.models[model_name].StaticStep(name='loading', previous='Initial',
                                      description='loading-step', maxNumInc=10000, initialInc=0.1, maxInc=0.1,
                                      nlgeom=ON)
    # creating a refrence point
    a = mdb.models[model_name].rootAssembly
    e1 = a.instances['Beam-1'].edges
    a.ReferencePoint(point=a.instances['Beam-1'].InterestingPoint(edge=e1.findAt(
        coordinates=(L1 / 4, 0.0, beam_depth)), rule=MIDDLE))
    a = mdb.models[model_name].rootAssembly
    e11 = a.instances['Beam-1'].edges
    a.ReferencePoint(point=a.instances['Beam-1'].InterestingPoint(edge=e11.findAt(
        coordinates=(L1 * 3 / 4, 2 * h2 + 2 * h3 + h4, beam_depth)), rule=MIDDLE))
    # defiing constranes-1
    a = mdb.models[model_name].rootAssembly
    e1 = a.instances['Beam-1'].edges
    edges1 = e1.findAt(((0.0, 0.0, beam_depth - (bearing_lengnth * 3 / 4)),))
    region3 = regionToolset.Region(edges=edges1)
    a = mdb.models[model_name].rootAssembly
    r1 = a.referencePoints
    refPoints1 = (r1[4],)
    region1 = regionToolset.Region(referencePoints=refPoints1)
    mdb.models[model_name].RigidBody(name='Constraint-1', refPointRegion=region1,
                                     pinRegion=region3)
    # defiing constranes-2
    a = mdb.models[model_name].rootAssembly
    e1 = a.instances['Beam-1'].edges
    edges1 = e1.findAt(((0.0, 2 * h2 + 2 * h3 + h4, beam_depth - (bearing_lengnth * 3 / 4)),))
    region3 = regionToolset.Region(edges=edges1)
    a = mdb.models[model_name].rootAssembly
    r1 = a.referencePoints
    refPoints1 = (r1[5],)
    region1 = regionToolset.Region(referencePoints=refPoints1)
    mdb.models[model_name].RigidBody(name='Constraint-2', refPointRegion=region1,
                                     pinRegion=region3)
    # defining boundry conditions
    a = mdb.models[model_name].rootAssembly
    v1 = a.instances['Beam-1'].vertices
    verts1 = v1.findAt(((0.0, 0.0, beam_depth - bearing_lengnth),), ((0.0, 0.0, beam_depth),))
    region = a.Set(vertices=verts1, name='supports')
    mdb.models[model_name].DisplacementBC(name='supports', createStepName='Initial',
                                          region=region, u1=SET, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET,
                                          amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)
    a = mdb.models[model_name].rootAssembly
    v1 = a.instances['Beam-1'].vertices
    verts1 = v1.findAt(((0.0, 2 * h2 + 2 * h3 + h4, beam_depth - bearing_lengnth),),
                       ((0.0, 2 * h2 + 2 * h3 + h4, beam_depth),))
    region = a.Set(vertices=verts1, name='loading-nodes')
    mdb.models[model_name].DisplacementBC(name='loading-nodes',
                                          createStepName='loading', region=region, u1=0.0, u2=-displacement, u3=0.0,
                                          ur1=0.0,
                                          ur2=0.0, ur3=0.0, amplitude=UNSET, fixed=OFF, distributionType=UNIFORM,
                                          fieldName='', localCsys=None)
    #creating hole
    p = mdb.models[model_name].parts['Beam']
    f, e, d2 = p.faces, p.edges, p.datums
    t = p.MakeSketchTransform(sketchPlane=f[13], sketchUpEdge=e[38],
                              sketchPlaneSide=SIDE1, sketchOrientation=RIGHT, origin=(18.5, 0.0, 0.0))
    s1 = mdb.models[model_name].ConstrainedSketch(name='__profile__',
                                                     sheetSize=750.46, gridSpacing=18.76, transform=t)
    g, v, d, c = s1.geometry, s1.vertices, s1.dimensions, s1.constraints
    s1.setPrimaryObject(option=SUPERIMPOSE)
    p = mdb.models[model_name].parts['Beam']
    p.projectReferencesOntoSketch(sketch=s1, filter=COPLANAR_EDGES)
    s1.CircleByCenterPerimeter(center=(-(beam_depth/2), (h2 + h3 + h4 / 2 )), point1=(-(beam_depth/2), (( h2 + h3 + h4 / 2 )+raduis)))
    p = mdb.models[model_name].parts['Beam']
    f1, e1, d1 = p.faces, p.edges, p.datums
    p.CutExtrude(sketchPlane=f1[13], sketchUpEdge=e1[38], sketchPlaneSide=SIDE1,
                 sketchOrientation=RIGHT, sketch=s1, flipExtrudeDirection=OFF)
    s1.unsetPrimaryObject()
    del mdb.models[model_name].sketches['__profile__']
    # meshing
    p = mdb.models[model_name].parts['Beam']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    session.viewports['Viewport: 1'].partDisplay.setValues(mesh=ON)
    session.viewports['Viewport: 1'].partDisplay.meshOptions.setValues(
        meshTechnique=ON)
    session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
        referenceRepresentation=OFF)
    p = mdb.models[model_name].parts['Beam']
    p.seedPart(size=mesh_size, deviationFactor=0.1, minSizeFactor=0.1)
    p = mdb.models[model_name].parts['Beam']
    p.generateMesh()
    a1 = mdb.models[model_name].rootAssembly
    a1.regenerate()
    a = mdb.models[model_name].rootAssembly
    # submitting jop
    mdb.Job(name=model_name, model=model_name, description='', type=ANALYSIS,
        atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90,
        memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True,
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF,
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='',
        scratch='', resultsFormat=ODB, numThreadsPerMpiProcess=1,
        multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
    # mdb.jobs[model_name].submit(consistencyChecking=OFF)

import array
H = array.array('i', [200,250, 300, 350])
B = array.array('i', [50,70, 100, 120])
S = array.array('i', [20,25, 30, 35])
T = array.array('i', [2,3,4])
L = array.array('i', [50,75,100])

cc=0

for h in H:
    for b in B:
        for s in S:
            for t in T:
                for l in L:
                    R = array.array('f', [0.12*h, 0.16*h, 0.18*h])
                    for raduis in R:
                        cc=cc+1
                        L1 = b
                        L2 = 0.37 * b
                        h1 = s
                        h2 = 0.2 * h
                        h3 = (1 / 17) * h
                        h4 = 0.47 * h
                        thick = t
                        beam_depth = 400
                        bearing_lengnth = l
                        displacement = 40
                        mesh_size = 8
                        model_name = 'BeamModel-'+str(cc)+ "h="+ str(h) + '-' +"b="+ str(b) + '-' +"s="+ str(s) + '-' +"t="+ str(t) + '-' +"l="+ str(l)
                        i3D_Beam(raduis,L1, L2, h1, h2, h3, h4, model_name, thick, beam_depth, bearing_lengnth, displacement,
                                 mesh_size)
                        # mdb.jobs[model_name].submit(consistencyChecking=OFF)


